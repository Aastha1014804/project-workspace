function show(msg)

{

    console.log(msg);

}

var pro= new Promise(function(myResolve,myReject)

{

let sum = 0;

const number = 153;

let temp = number;

while (temp > 0) {

   

    let remainder = temp % 10;

