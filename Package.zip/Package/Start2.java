package mypack;
public class Start2
{
   public void display()
    {
       System.out.println("I'm in Display method");
     }
}