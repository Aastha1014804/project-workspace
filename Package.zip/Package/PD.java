import mypackage.Start;
class PD{
  public static void main(String args[])
   {
     Start s=new Start();
     s.display();
   }
}