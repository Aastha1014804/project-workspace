package mypackage;
public class Start
{
   public void display()
    {
       System.out.println("I'm in Display method");
     }
}