import mypack.Start2;
class PDclassPath{
  public static void main(String args[])
   {
     Start2 s=new Start2();
     s.display();
   }
}