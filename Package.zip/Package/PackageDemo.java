import mypackage.Start;
class PackageDemo
{
  public static void main(String argds[])
   {

        //mypackage.Start ob=new mypackage.Start();
Start ob=new Start();        
ob.display();
    }
}