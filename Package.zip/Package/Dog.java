import mypackageDemo.Animal;
class Dog
{
    public static void main(String args[])
    {
       Animal d=new Animal();
        d.run();

      }
}