import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZonedDateTime;

  
public class DateTimeAPI {
 
public static void LocalDateTimeApi()
{
  
    LocalDate date = LocalDate.now();
    System.out.println("the current date is" + date);
  
    LocalTime time = LocalTime.now();
    System.out.println("the current time is " + time);
   
    LocalDateTime current = LocalDateTime.now();
    System.out.println("current date and time : "+
                        current);
  
  
    Month month = current.getMonth();
    int day = current.getDayOfMonth();
    int seconds = current.getSecond();
    System.out.println("Month : "+month+" day : "+ day + " seconds : " + seconds);
  
    LocalDate date2 = LocalDate.of(1999,7,17);
    System.out.println("Birthday :" + date2);
	
	ZonedDateTime cz = ZonedDateTime.now();
    System.out.println("the current zone is "+ cz.getZone());
						
   
}
 

    public static void main(String[] args)
    {
        LocalDateTimeApi();
    }
}