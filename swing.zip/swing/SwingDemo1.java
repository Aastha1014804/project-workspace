import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JLabel;
class SwingDemo1
{
   public static void main(String args[])
   {
       JFrame f=new JFrame();
	   JButton b=new JButton("click me");
	   b.setBounds(120,90,90,30);
	   f.add(b);
	   f.setSize(500,700);
	   f.setVisible(true);
	 
	    JPanel p = new JPanel();
	 
        p.setBounds(40,60,100,100);    
        p.setBackground(Color.blue);  
		f.add(p);
		JLabel l = new JLabel("nothing entered");
		p.add(l);
		 String week[]= { "Monday","Tuesday","Wednesday",
                         "Thursday","Friday","Saturday","Sunday"};
        JList jl= new JList(week);
		f.add(jl);
        
		f.show();
		
		
		
   }
}