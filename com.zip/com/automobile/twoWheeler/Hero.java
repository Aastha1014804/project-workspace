package com.automobile.twoWheeler;

import com.automobile.Vehicle;

public class Hero extends Vehicle 
{
	public int getSpeed()
	
	{
		return 100;
	}
	public void radio()
	{
		System.out.println("Radio");
	}
	
	public String getModelName()
	{
		return "HERO";
	}
	public String getRegistrationNumber()
	{
		return ""5556";
	}
	public String getOwnerName()
	{
		return "Shyam";
	}
}