package com.automobile.twoWheeler;
import com.automobile.Vehicle;
public class Honda  extends Vehicle
{
public int getSpeed()
{
return 80;
}
public void cdPlayer() 
{
System.out.println("CD Player");
}
public String getModelName()
{
return "Honda";
}
public String getRegisterationumber()
{
return "MP1432";
}
public String getOwnerName()
{
return "Ram";
}

}