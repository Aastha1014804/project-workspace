package com.automobile;
import com.automobile.twoWheeler.*;
public class Test extends Vehicle
{
	public static void main(String[] args)
	{
		Honda h=new Honda();
		int sp=h.getSpeed()
		System.out.println(sp);
	}
}