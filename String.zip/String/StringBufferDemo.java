class StringBufferDemo{
    public static void main(String args[])
     {
      StringBuffer sb=new StringBuffer("Yash")
      sb.append("Technologies");
      System.out.println(sb);
      String s=new String("yash");
      s.concat("Technologies");
      System.out.println(s);
     StringBuffer sb=new StringBuffer();
     System.out.println(sb.capacity());     }
}