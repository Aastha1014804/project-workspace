class StringBufferFunction{
      public static void main(String args[])
       {
          StringBuffer sb=new StringBuffer("Welcome to Yash Technologies");
          System.out.println(sb.deleteCharAt(7));
           StringBuffer sb1=new StringBuffer("Yash");
             StringBuffer sb2=new StringBuffer("Yash");
          System.out.println(sb1.equals(sb2));
          System.out.println(sb.indexOf("e"));
          System.out.println(sb.lastIndexOf("e"));
          System.out.println(sb.insert(0,"jaynam"));
          System.out.println(sb.replace(0,6,null)); //error
          System.out.println(sb.reverse());
          System.out.println(sb.subSequence(0,6));
          System.out.println(sb.substring(3,7));
          sb.setCharAt(8,'y')
          System.out.println(sb);
          System.out.println(sb.substring(3,7));
  }
}