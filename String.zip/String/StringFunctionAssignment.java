class StringFunctionAssignment{
      public static void main(String args[])
       {
          String s=new String("Welcome to Yash Technologies");
          String s1=new String("Welcome to Yash");
          String s2=new String("Welcome to Yash Technologies");
          String s3=new String("welcome to yash");
           String s4=new String();
         
          System.out.println(s.isEmpty());
          System.out.println(s4.isEmpty());
          System.out.println(s.trim());
         
          System.out.println(s.equals(s1));
          System.out.println(s.equalsIgnoreCase(s2));
          System.out.println(s.compareTo(s1));
          System.out.println(s1.compareToIgnoreCase(s3));
          System.out.println(s.substring(3,5));
          
  }
}