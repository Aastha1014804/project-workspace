class StringEvenLength{
      public static void main(String args[])
       {
          String s=new String(args[0]);
          int len,c=1;
          len=s.length();
          
          if(len%2==0)
          System.out.println(s.substring(0,len/2));
          else
          System.out.println("Null");
         
          
  }
}