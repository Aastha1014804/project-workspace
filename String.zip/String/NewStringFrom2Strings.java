class  NewStringFrom2Strings{
      public static void main(String args[])
       {
          String x=new String(args[0]);
          String y=new String(args[1]);
          String s=new String();
          int j=0,k;
          if(x.length()==y.length())
         {
           for(int i=0; i<x.length(); i++)
             {
               s =s+x.charAt(i);
               s=s+y.charAt(i);

              }
             System.out.println(s);
            }
         
          else
         {
            if(x.length()>y.length())
           {
             for(int i=0; i<y.length(); i++)
             {
               s=s+x.charAt(i);
               s=s+y.charAt(i);
               j++;
                
              } 
                for(k=j; k<x.length(); k++)
                 {
                    s=s+x.charAt(k);
                     }       
                System.out.println(s);
                }
           else{
                 for(int i=0; i<x.length(); i++)
             {
               s=s+x.charAt(i);
               s=s+y.charAt(i);
               j++;
                
              } 
                for(k=j; k<y.length(); k++)
                 {
                    s=s+y.charAt(k);
                     }       
                System.out.println(s);
                  }
           
         }
}
}