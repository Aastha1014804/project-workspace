class StringPalindrom{
      public static void main(String args[])
       {
          String s=new String(args[0]);
          int i, j,c=1;
          for(i=0,j=4;i<j;i++,j--)
         {
            if(s.charAt(i)!=s.charAt(j))
           {
               c=0;
               break;
              }
           }
          
          if(c==1)
          System.out.println("Palindrom");
          else
          System.out.println("Not Palindrom");
         
          
  }
}