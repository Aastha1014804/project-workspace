class StringFirststAndLastRemove{
      public static void main(String args[])
       {
          String s=new String(args[0]);
          int len;
          len=s.length();
          
          if(len<2)
          System.out.println("Null");
          else
         {
           
            System.out.println(s.substring(1, s.length() - 1));
         
          
  }
}