class Animal{  
   
  void run()
   {
     System.out.println("Running slow");}  
     }  
 
class Dog extends Animal{ 
   
  void run()
    {
      System.out.println("running fast");
       return 0;
     }  
  
  public static void main(String args[]){  
  Dog obj = new Dog();  
  obj.run();  
  }  
}  