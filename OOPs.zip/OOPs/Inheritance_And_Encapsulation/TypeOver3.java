class TypeOver3
{
   void display(StringBuffer a)
   {
   System.out.println("String buffer method");
    }

   void display(String a)
  {
   System.out.println("String  method");   
    }

  public static void main(String args[])
  {
   TypeOver3 t=new TypeOver3();
    t.display("aastha");   //string method
    t.display(new StringBuffer("yash")); //stringBuffer method
   }
}

