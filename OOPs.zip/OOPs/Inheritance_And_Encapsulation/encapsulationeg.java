class Employee
{
    private int emp_id;  //data hiding
     public void setEmpId(int emp_id)
     {
       this.emp_id=emp_id;
      }
     public int getEmpId()
     {
       return emp_id;
      }
}

// this Employee class shows encapsulation

class Organization
{
   public static void main(String args[])
   {
     employee e=new Employee();
     e.setEmpId(1000);
     System.out.println(e.getEmpId());
   }
}