class A
{ 
    void displayA()
     { 
       System.out.println("A class");
         }
}

class SingleInheritanceEg extends A
{
    void displayB()
   {
      System.out.println("B class");
    }
      
 public static void main(String args[])
   { 
       A ob1=new A();
        ob1.displayA();
        //ob1.display();
       SingleInheritanceEg ob2=new SingleInheritanceEg();
        ob2.displayA();
        ob2.displayB();
   }
}