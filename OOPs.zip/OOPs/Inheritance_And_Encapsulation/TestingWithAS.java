class Animal{  
   
  public void run()
   {
     System.out.println("Object method");
      }
     }  
 
class TestingWithAS extends Animal{ 
   
  public void run()
    {
      System.out.println("string method");
      
     }  
  
  public static void main(String args[]){  
  TestingWithAS obj = new TestingWithAS();  
  obj.run();  
  }  
}  



