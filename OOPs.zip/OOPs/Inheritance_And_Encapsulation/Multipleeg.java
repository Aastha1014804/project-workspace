class A
{ 
    void display()
     { 
       System.out.println("A class");
         }
}

class B 
{
    void display()
   {
      System.out.println("B class");
    }
  }

class C extends A,B{
       
    public static void main(String args[])
   { 
      
        C ob3=new C();
        ob3.display();
       
   }
}