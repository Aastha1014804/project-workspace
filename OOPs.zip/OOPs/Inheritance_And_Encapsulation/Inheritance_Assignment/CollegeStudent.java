class Person{  
   
   String name,dateOfBirth;
     Person(String n,String dob)
  { 
     name=n;
     dateOfBirth=dob;
 
  }

 void show()
 {
   System.out.println("Person name is: " + name);

   System.out.println("Person's Date of Birth is: " + dateOfBirth);
   
   }

   }  
 
class Teacher extends Person
{ 
    int salary;
    String subject;
    Teacher(int sal, String sub)
  { 
   salary=sal;
   subject=sub;
 
  }

 void show()
 {
   System.out.println("Teacher's Salary is: " + salary);

   System.out.println("Teacher's Subject is: " + subject);
   
   }
    
   }

class Student extends Person
{
  int studentId;
  Student(int id)
{ 
   studentId=id;
 
  }

 void show()
 {
   System.out.println("Student id is: " + studentId);
   }
  
}

class CollegeStudent extends Student
{
  String clgName,year;
  CollegeStudent(String cn,String y)
{ 
   clgName=cn;
    year=y;
 
  }

 void show()
 {
   System.out.println("College name is: " + clgName);

   System.out.println("Year : " + year);
   
   }
  
  public static void main(String args[]){    
   CollegeStudent cs = new CollegeStudent("Davv","Second"); 
   Student s = new Student(101); 
    Teacher t=new Teacher(20000,"Maths");
    Person p=new Person("Aastha","JUly");

   cs.show();
    s.show();
   t.show();
   p.show();
  
 
  }  
}  



