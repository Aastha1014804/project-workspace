class Person{  
   
   String name,dateOfBirth;
     Person(String name,String dateOfBirth)
  { 
     this.name=name;
     this.dateOfBirth=dateOfBirth;
 
  }

   }  
 
class Teacher extends Person
{ 
    int salary;
    String subject;
    Teacher(String name ,String dateOfBirth,int salary, String subject)
  { 
   super(name,dateOfBirth);
   this.salary=salary;
   this.subject=subject;
 
  }

 void show()
 {
    System.out.println("Name: " + name);
    System.out.println("Teacher's Salary is: " + salary);

   System.out.println("Teacher's Subject is: " + subject);
   
   }
    
   }

class Student extends Person
{
  int studentId;
 Student(String name ,String dateOfBirth,int studentId)
{ 
 super(name,dateOfBirth);
this.studentId=studentId;
 
  }

  
}

class CollegeStudent extends Student
{
  String clgName;
  String year;
  CollegeStudent(String name ,String dateOfBirth,int studentId,String clgName,String year)
{ 
    super(name,dateOfBirth,studentId);
    this.clgName=clgName;
    this.year=year;
 
  }
 

  void show()
{
   System.out.println("Name: " + name);
   System.out.println("College Name: " + clgName);
   System.out.println("Year: " + year);
}

 }

class CollegeApplication{
 
  public static void main(String args[]){    

   Teacher t=new Teacher("Jay","17/07/1999",20000,"Maths");
   CollegeStudent cs = new CollegeStudent("Shivam","18/07/1999",101,"Davv","Second"); 
  cs.show();

   
 
  }  
}  



