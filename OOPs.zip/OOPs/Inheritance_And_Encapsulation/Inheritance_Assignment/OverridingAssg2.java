class Fruit{  
   
   String name="Mango";
   String taste="sweet";
   String size="Small";

    

 void show()
  {
      System.out.println("Name: " + name);
    System.out.println("Taste is: " + taste);
      System.out.println("Size is: " + size);
  
         }
   }  
 
class Apple extends Fruit
{ 
    
  String name="Apple";
   String taste="Sweet";
   String size="Small";
 
 void show()
  {
     
      System.out.println("Name: " + name);
    System.out.println("Taste is: " + taste);
      System.out.println("Size is: " + size);
         }


    
   }

class Orange extends Fruit
{

  String name="Orange";
   String taste="Soar";
   String size="Medium";
   
  
 void show()
  {
      super.show();
      System.out.println("Name: " + name);
    System.out.println("Taste is: " + taste);
      System.out.println("Size is: " + size);
         }
 

  
}

class OverridingAssg2
{
  
 
  public static void main(String args[]){    
   
   Orange o=new Orange();
   Apple a=new Apple();
   o.show();
   a.show();
   

   
 
  }  
}  



