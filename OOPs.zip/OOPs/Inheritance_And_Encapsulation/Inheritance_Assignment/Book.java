class Author{  
   private String name,email;
   private char gender;
   public void setter(String n, String e,char g)
   {
     this.name=n;
     this.email=e;
     this.gender=g;
         
      }
   public String gettername()
   {
     return this.name;
     }
    public String getteremail()
   {
     return this.email;
     }
    public char gettergender()
   {
     return this.gender;
     }

   }  
 
class Book extends Author
{ 
   String name,author;
   double price;
   int qtylnStock;
   Book(String name,double price, int qtylnStock)
    {
       this.name=name;
     this.price=price;
     this.qtylnStock=qtylnStock;
      
     }  

   
 
  public static void main(String args[]){  
   
  Book obj = new Book("Ram",1100, 123);  
  Author au=new Author();
  au.setter("Anubhav","anubhav12@gmail.com",'M');
    System.out.println("Name of Book : " + obj.name);
    String na=au.gettername();
    System.out.println("Author of Book : " + na);
    String em=au.getteremail();
    System.out.println("Author's email : " + em);
    char gen=au.gettergender();
    System.out.println("Author's gender : " + gen);
    System.out.println("Price of Book : " + obj.price);
    System.out.println("Quantity of Book : " + obj.qtylnStock ); 
  }  
}  



