class Animal{  
   
    void eat()
   {
     System.out.println("I'm Eating");
         
      }

  void sleep()
   {
     System.out.println("I'm Sleeping");
         
      }
  

   }  
 
class Bird extends Animal
{ 

    void eat()
   {
     System.out.println("Bird Eating");
         
      }

  void sleep()
   {
     System.out.println("Bird Sleeping");
         
      }
    void fly()
   {
     System.out.println("Bird Flying");
         
      }
  
  public static void main(String args[]){    
  Animal obj = new Animal();  
  obj.eat(); 
  obj.sleep(); 
  Bird obj1 = new Bird();  
  obj1.eat(); 
  obj1.sleep(); 
  obj1.fly();
 
  }  
}  



