class Animal{  
   
  String run()
   {
     System.out.println("Object method");
      }
     }  
 
class Testing extends Animal{ 
   
  Object run()
    {
      System.out.println("string method");
      
     }  
  
  public static void main(String args[]){  
  Testing obj = new Testing();  
  obj.run();  
  }  
}  

// error


