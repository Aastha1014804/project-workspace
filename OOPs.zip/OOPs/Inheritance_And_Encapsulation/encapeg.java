class Employee
{
    private int emp_id;  //data hiding
     public void setEmpId(int emp_id)
     {
       this.emp_id=emp_id;
      }
     public int getEmpId()
     {
       return emp_id;
      }
}