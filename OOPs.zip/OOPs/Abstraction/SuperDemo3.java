class A
{
   A()
{
System.out.println("Hi I'm in class A");
}

}
class SuperDemo3 extends A
{
    SuperDemo3()
{

//super();
System.out.println("Hi I'm in class SuperDemo3");
}


   public static void main(String args[])
   {
       SuperDemo3 sd=new SuperDemo3();
       
  }
}