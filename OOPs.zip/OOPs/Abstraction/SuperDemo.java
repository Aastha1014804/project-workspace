class A
{
int a=100;
A()
{
System.out.println("Hello");
}

void show()
{
System.out.println("Hi");
}

}
class SuperDemo extends A
{
    int a=200;
    SuperDemo()
  {
    super();
   }
    void display(int a)
   {
    super.show();
    System.out.println(a);
     System.out.println(this.a);
    System.out.println(super.a);
    
   }
   public static void main(String args[])
   {
       SuperDemo sd=new SuperDemo();
       sd.display(300);
  }
}