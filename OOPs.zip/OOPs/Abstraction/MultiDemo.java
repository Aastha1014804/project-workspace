interface A
{
     void show();
     
}

interface B
{
     void display();
     
}

class MultiDemo implements A,B
{
   public void show()
  {
    System.out.println("In show class");
}


    public void display()
  {
    System.out.println("In display class");
}

public static void main(String args[])
{
   //A1 a=new A1();
   MultiDemo md=new MultiDemo();
   md.show();
   md.display();

}

}