class Vehicle
{
    void start()
     {
       }

 }