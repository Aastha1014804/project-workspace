interface A1
{
     void show();
     int a=20;
}

class InterfaceDemo implements A1
{
   public void show()
  {
    System.out.println("In demo class");
}

public static void main(String args[])
{
   //A1 a=new A1();
   InterfaceDemo d=new InterfaceDemo();
   d.show();

}

}