abatract class Vehicle
{
    abstract void start();

 }

class Car extends Vehicle
{

   void start()
   {
     System.out.println("Starts by key/Button");
     }
}

class Bike extends Vehicle
{

   void start()
   {
     System.out.println("Starts by kick");
     }

   public static void main(String args[])
    {
       Car c=new Car();
       c.start();
       Bike b=new Bike();
       b.start();
  }
}

