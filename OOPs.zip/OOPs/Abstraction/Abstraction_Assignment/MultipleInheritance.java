interface Square
{
     void perimeter();
     
}

interface Circle
{
     void area();
     
}

class MultipleInheritance implements Square,Circle
{
   public void perimeter()
  {
    int p=4*5;
    System.out.println("Perimeter: " + p);
}


    public void area()
  {
    double a=3.14*7*7;
    System.out.println("Area of Circle is: " + a);
}

public static void main(String args[])
{
   
   MultipleInheritance mi=new MultipleInheritance();
   mi.area();
   mi.perimeter();

}

}