class Parent
{
String s="Ram";
Parent()
{
System.out.println("Parent's Constructor");
}

void show()
{
System.out.println("Hello I'm Parent" + s);
}

}
class SuperProgram extends Parent
{
   String s="Shyam";
    SuperProgram()
  {
    super();
   }
    void display()
   {
    super.show();
    System.out.println("I'm in display method");
    System.out.println(this.s);
    System.out.println(super.s);
    
   }
   public static void main(String args[])
   {
       SuperProgram sp=new SuperProgram();
       sp.display();
  }
}