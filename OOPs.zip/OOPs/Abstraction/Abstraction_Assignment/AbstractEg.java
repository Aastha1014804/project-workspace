abstract class Animal
{
    abstract void run();

 }

class Cat extends Animal
{

   void run()
   {
     System.out.println("I run slow");
     }
}

class Dog extends Animal
{

   void run()
   {
     System.out.println("I run fast");
     }
}

class AbstractEg{

   public static void main(String args[])
    {
       Cat c=new Cat();
       c.run();
       Dog d=new Dog();
       d.run();
  }
}

