class Father {
   String name="Ram";
  
   void display() {
      System.out.println(name);
   }
}
class Child extends Father {
   String cname="Anu";
  
   public void display() {
      System.out.println(cname);
   }
}
public class ClassCastExceptionEg {
   public static void main(String args[]) {
      Child c = new Child();
      Father p = new Father();
     
      p.display();

      Father p1 = new Father();
      Child c1 = (Child)p1;
   }
}