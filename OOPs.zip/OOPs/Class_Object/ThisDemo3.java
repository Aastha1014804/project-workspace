class ThisDemo3{

      ThisDemo3()
     {
       System.out.println("No argument constructor");
       } 
     ThisDemo3(int a)
     {
        this();
        System.out.println("Parameterized constructor");
         }
    public static void main(String args[])
    {
          ThisDemo3 t=new ThisDemo3();

     }

}