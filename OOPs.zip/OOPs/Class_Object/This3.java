class This3{
       
      This3()
         {
     System.out.println("Demo");
            
      }
     This3(int a)
      {
          this();
         System.out.println("Demo hi");
        }
    public static void main(String args[])
    {
          This3 t=new This3(14);
         
         }
}