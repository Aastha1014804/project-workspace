class DemoCons
{
  final DemoCons()

   {
        System.out.println("I'm eating");
  }
  public static void main(String args[])
  {
    
    DemoCons s=new DemoCons();
    }

}

