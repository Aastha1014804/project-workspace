class Box{
      int h,w,d;
    Box(int w,int h,int d)
     {
         this.w=w;
         this.h=h;
         this.d=d;
        }

     int volume()
      {
          int v=h*w*d;
         
           return v;
          }
    public static void main(String args[])
     { 
        Box b=new Box(10,20,30);
         int ans= b.volume();
         System.out.println(ans);
      }   


}