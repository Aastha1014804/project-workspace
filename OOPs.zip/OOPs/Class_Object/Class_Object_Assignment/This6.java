class This6{
      int i=6;
      int y1()
         {

           return this.i;  
      }
    public static void main(String args[])
    {
          This6 t=new This6();
           int ans= t.y1();
           System.out.println(ans);
         }

}