class Patient{
      String name;
      double h,w;
   Patient(String name,double h,double w)
     {
         this.name=name;
         this.h=h;
         this.w=w;
        }

     double computeBMI()
      {
          double c= (w)/(h*h);
          
           return c;
          }
    public static void main(String args[])
     { 
        Patient p=new Patient("Rahul",100,20);
         double ans= p.computeBMI();
        System.out.println(ans);
      }   


}