class TypeConstructor
{

  String name;
  int id;
  
  TypeConstructor(String s,int a)

   {
       this.name=s;
       this.id=a;
        System.out.println("I'm Parameterized Constructor");
  } 
    
  TypeConstructor()
  {
    System.out.println("I'm No argument Constructor");
     } 

   void display()
  {
    System.out.println(name + " " + id);
     }

  public static void main(String args[])
  {
    TypeConstructor t=new TypeConstructor();
    TypeConstructor t1=new TypeConstructor("Yash",111);
    t1.display();
    
    }

}

