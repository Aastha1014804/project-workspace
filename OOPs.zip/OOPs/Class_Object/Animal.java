class Animal
{
   public void eat()

   {
        System.out.println("I'm eating");
  }
  public static void main(String args[])
  {
    System.out.println("Hello");
    Animal sheru=new Animal();
    sheru.eat(); 
     Birds b=new Birds();
    b.fly;
 }

 public void run()

   {
        System.out.println("I'm running");
  }


}
class Birds
{
     void fly()
       {
       System.out.ptintln("I'm flying");
   }
 }