class This4{


      void m1(This4 t)
    {
     System.out.println("Yash Tech");   
      }
      void m2()
     {
       m1(this);
       } 
    
    public static void main(String args[])
    {
          This4 th=new This4();
           th.m2();
     }

}