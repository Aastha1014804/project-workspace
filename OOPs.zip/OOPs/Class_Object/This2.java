class This2{
       
      void y1()
         {
     System.out.println("Demo");
            
      }
     void y2()
      {
          y1();
        }
    public static void main(String args[])
    {
          This2 t=new This2();
           t.y1();
         }
}