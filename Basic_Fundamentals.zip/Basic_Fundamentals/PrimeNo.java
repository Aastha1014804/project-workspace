class PrimeNo
{
     public static void main(String args[])
{  
     
     int a=Integer.parseInt(args[0]);
int c=1;
     for(int i=1; i<a/2; i++)
{   
     if(a%i == 0)
    {  
         c=0;
         
        } 
   }
     
   if(c==1)
     System.out.println("Prime number");
else
 System.out.println("Not prime number");
}
}