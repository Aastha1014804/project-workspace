class Armstrong
{
    public static void main(String args[])
{
     int a=Integer.parseInt(args[0]);
       int arm=0;
 
    while(a!=0)
    {  
        int rem = a%10;
        arm = arm + rem*rem*rem;
        a = a/10;
}
   if(a==arm)
    System.out.println("Armstrong Number.");

   else
   System.out.println("Not Armstrong Number.");
}
}

