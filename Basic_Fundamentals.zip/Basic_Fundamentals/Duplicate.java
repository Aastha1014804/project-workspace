class Duplicate{
       public static void main(String[] args)
    {   
        
        int[] a={12,30,15,16,30};
        
        int temp=0;
        int[] tp = new int[5];
    
            for(int i=0; i<4;i++)
         { 
           for(int j=0; j<5-i-1; j++){
           if(a[j]>a[j+1])
            {
             temp =a[j];
             a[j]=a[j+1];
             a[j+1]= temp;
           }
           }
}
  int n=0;
     for(int i=0; i<4; i++)
    {
        if(a[i]!=a[i+1])
         tp[n++]=a[i];
        }

              tp[n++] = a[4];
  
        for (int m = 0; m < n; m++) {
            a[m] = tp[m];
        }

 
    for(int k=0; k<n; k++)
    System.out.println(a[k] + " ");

      }
  }
