class PalindromNo
{
    public static void main(String args[])
{
     int n=Integer.parseInt(args[0]);
    int rn = rev(n);
    if(n==rn)
    System.out.println("Palindrom Number.");
    else
    System.out.println("Not Palindrom Number.");
}

 public static int rev(int a)
{
    
    int r=0;
    while(a!=0)
    {  
        int rem = a%10;
        r = r*10 + rem;
        a = a/10;
}
   return r;
}
}

