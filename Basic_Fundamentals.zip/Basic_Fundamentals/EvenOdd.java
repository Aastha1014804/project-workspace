class EvenOdd
{
  public static void main(String args[])

{
     int a=Integer.parseInt(args[0]);
    
     if(a%2 == 0)
{
System.out.println("Even number");
}

else
{
  System.out.println("Odd number");
}

}
}