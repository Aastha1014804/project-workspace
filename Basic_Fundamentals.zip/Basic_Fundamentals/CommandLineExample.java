class CommandLineExample
{ 
   public static void main(String args[])
    {
          int a=Integer.parseInt(args[0]);
          float b=Float.parseFloat(args[1]);
          double c=Double.parseDouble(args[2]);
          System.out.println("Your First Argument is:" + args[0]);
          System.out.println("Your Second Argument is:" + args[1]);
          System.out.println("Your Third Argument is:" + args[2]);
          
}
}