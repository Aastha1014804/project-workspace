class Fibonacci
{
    public static void main(String args[])
{
     int n=Integer.parseInt(args[0]);
int a=0, b=1, c;
     if(n==1)
     System.out.println(n);
     else if(n==2)
     System.out.println(n);
    
     else
   {
    System.out.println("1");
    for(int i=2; i<n; i++)
      {
     c=a+b;
     System.out.println(c);
     a=b;
     b=c;
      }
   }
}
}

