class PrimeNoAddition
{
     public static void main(String args[])
{  
     
     int a=Integer.parseInt(args[0]);
     int sum=0;
     for(int i=2; i<=a; i++)
    { 
       if(isprime(i)==1)
       sum = sum+i;
}

   System.out.println("Sum of prime numbers is = " +sum);
}
    public static int isprime(int a)
    {
 int c=1;
     for(int i=1; i<a/2; i++)
{   
     if(a%i == 0)
    {  
         c=0;
         break;
        } 
   }
     
   return c;
}

}