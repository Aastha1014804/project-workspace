class factorialRec
{
     public static void main(String args[])
{  
     
     int a=Integer.parseInt(args[0]);
      long f = multiplyNumbers(a);
     System.out.println("Factorial = " + f);
}

     public static long multiplyNumbers(int a)
    {
        if (a >= 1)
            return a * multiplyNumbers(a - 1);
        else
            return 1;
    }
}