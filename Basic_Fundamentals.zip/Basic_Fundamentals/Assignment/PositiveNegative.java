class PositiveNegative
{
   public static void main(String args[])
{
   int a=Integer.parseInt(args[0]);
   if(a>0)
{
  System.out.println("Positive number");
}
 else if(a==0)
{
  System.out.println("Zero");
}
else {
   System.out.println("Negative number"); 
}
}
}