class Reverse
{
     public static void main(String args[])
{  
     
     int a=Integer.parseInt(args[0]);

     
    System.out.println("Actual number" + a);
    int r=0;
    while(a!=0)
    {  
        int rem = a%10;
        r = r*10 + rem;
        a = a/10;
}
     System.out.println("Reversed number" + r);
}
}