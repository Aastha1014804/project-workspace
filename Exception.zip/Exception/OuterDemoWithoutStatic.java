class Outer
{
   
    class Inner
   {
	    void show()
   {
	   System.out.println("Outer show");
   }
   }
 }
 public class OuterDemoWithoutStatic
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 
		 Outer.Inner oi=o.new Inner();
		 oi.show();
	 }
 }