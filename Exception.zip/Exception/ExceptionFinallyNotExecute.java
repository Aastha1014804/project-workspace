class ExceptionFinallyNotExecute
{
   public static void main(String args[])
 {
        try
         {
            int a=100,b=0,c=0;
           System.out.println(c);
           System.exit(0);
         }

finally{
System.out.println("i'm in finally block");
}
}
}

















