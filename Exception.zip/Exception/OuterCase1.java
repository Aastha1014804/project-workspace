 static class Outer
{
   void show1()
   {
      System.out.println("Hello outer method");
   }
    class Inner
   {
	    void show()
   {
	   System.out.println("Inner show method");
   }
   }
 }
 public class OuterCase1
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 o.show1(); 
		
	 }
 }
 
 // modifier static not allowed