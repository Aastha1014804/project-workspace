import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.lang.ClassNotFoundException;
import java.util.Scanner;

class ThrowExp1
{
	void show() throws FileNotFoundException
	{
		FileInputStream fis=new FileInputStream("d:/yash/aabbc.txt");
	}
}

abstract class AbstractClass
{
int ab;
}

class CheckedExceptionImplementation
{
     public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 
		  ThrowExp1 t=new ThrowExp1();
		   FileInputStream f = null;
		 
		 
	   try{
		   
		  t.show(); 
		  
	   }	      
	  
	   catch(FileNotFoundException e)
	   {
	      System.out.println("FileNotFound  Exception occurs: ");
	   
	   }
	   
	   try{
		   Class c=Class.forName("Class not found exception");
	   
	   }
	   catch(ClassNotFoundException c)
	   {
		   System.out.println(c.getMessage());
	   }
	   
	 
      try{
             f = new FileInputStream("d:/yash/abcxyz");
               f.read();
         }
		 catch (IOException e){
             System.out.println("IO  Exception occurs: ");
            }
	   }
} 
	   
	   
	   
	   
	   
	   
	   