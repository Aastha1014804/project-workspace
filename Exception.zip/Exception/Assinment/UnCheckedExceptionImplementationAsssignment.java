import java.io.*;
import java.util.Scanner;
class UnCheckedExceptionImplementationAsssignment
{
     public static void main(String args[])
	 {
		Scanner sc=new Scanner(System.in);
	   int a=10,b=0,c,d;
	  UnCheckedExceptionImplementationAsssignment u=null;
	  int[] arr=new int[5];
	  String st="Yash Tech";
	   try
	   {   
	      c=a/b;
		  }
	   
	   
        catch(ArithmeticException e)
	   {
	      System.out.println("Arithmetic Exception occurs: ");
	      
	   }
	    try{
		  u.toString();
		  }
	   
	   catch(NullPointerException e)
	   {
	      System.out.println("NUll Pointer  Exception occurs: ");
	   
	   }
	   
	    try{
		  System.out.println(arr[6]);
		  }
	   
	   catch(ArrayIndexOutOfBoundsException e)
	   {
	      System.out.println("ArrayIndexOutOfBoundsException  Exception occurs: ");
	   
	   }
	   
	     try{
		  System.out.println(st.substring(16));
		  }
	    catch(StringIndexOutOfBoundsException e)
	   {
	      System.out.println("StringIndexOutOfBoundsException  Exception occurs: ");
	   
	   }
	   
	   try{
		  d=Integer.parseInt(sc.nextLine());
		  }
		
	   
	    catch(NumberFormatException e)
	   {
	      System.out.println("NumberFormatException  Exception occurs: ");
	   
	   }
	   
	   
	   }
	   }
	   
	   
	   
	   
	   
	   
	   
	   