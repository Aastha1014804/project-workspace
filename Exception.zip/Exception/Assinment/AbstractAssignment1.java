abstract class GeneralBank
{
  abstract double getSavingsInterestRate();
  abstract double getFixedDepositInterest();
 }
 
class ICICIBank extends GeneralBank
{
  double getSavingsInterestRate()
  {
     return 4.0;
	 }
    double getFixedDepositInterest()
   {
     return 8.5;
	 }
 }
 
class SBIBank extends GeneralBank
{
  double getSavingsInterestRate()
  {
     return 4.0;
	 }
    double getFixedDepositInterest()
   {
     return 7.0;
	 }
 }
 
 class AbstractAssignment1
 {
    public static void main(String args[])
	{
	   ICICIBank i=new ICICIBank();
	   SBIBank s=new SBIBank();
	   System.out.println(i.getSavingsInterestRate());
	   System.out.println(i.getFixedDepositInterest());
	   System.out.println(s.getFixedDepositInterest());
	   System.out.println(s.getSavingsInterestRate());
	   }
	   }
	   
	   