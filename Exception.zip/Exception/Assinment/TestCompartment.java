import java.util.Random;
abstract class Compartment
{
  public abstract void notice();
 }
 
class FirstClass extends Compartment
{

   public void notice()
   {
   System.out.println(" You're in FirstClass");
   }
  
 }
 
class Ladies extends Compartment
{
  
  public void notice()
   {
     System.out.println("You're in Ladies");
   }
  
 }

class General extends Compartment
{

  public void notice()
   {
    System.out.println(" You're in General");
   }
  
 }
 
class Luggage extends Compartment
{

   public void notice()
   {
     System.out.println(" You're in Luggage");
   }
  
 }
 
 
public class TestCompartment
 {
    public static void main(String args[])
	{
	   Compartment[] c= new Compartment[10];
	   Random r = new Random();
        for(int i=0;i<10;i++)
		{
			int rno=r.nextInt(4) + 1;
			if(rno==1)
			{
				c[i] = new FirstClass();
			}
			
			else if(rno==2)
			{
				c[i] = new Ladies();
			}
			
			else if(rno==3)
			{
				c[i] = new General();
			}
			
			else if(rno==4)
			{
				c[i] = new Luggage();
			}
			
			c[i].notice();
			
		}
	 }
 }
	   
	   