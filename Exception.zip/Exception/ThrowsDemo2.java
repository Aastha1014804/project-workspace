
import java.io.IOException;
class ThrowsDemo2
{
   void show() throws IOException
    {
	  throw new IOException("Exception");
	}
	
	void show2() throws IOException
	{
		show();
	}
	
    void show3()
	{
		try{
			show2();
		}
		
		catch(IOException e)
		 {
			 e.printStackTrace();
		 System.out.println("Hello normal termination");
		 }
	}		 

	 public static void main(String args[])
	 {
		 ThrowsDemo2 t=new ThrowsDemo2();
         t.show3();
		 System.out.println("normal flow");
		 
	 }
}