import java.util.Scanner;

class InvalidCountryException extends RuntimeException
{
    InvalidCountryException(String s)
     {
         super(s);
}

}

class UserRegistration
{

void registerUser(String username,String userCountry)  
{
    
         try{ 
        if(userCountry.equals("India"))
        {
            System.out.println("You are Successfully registered: ");
       }
       else{
        throw new InvalidCountryException("User outside India cannot be registered");
        }
}
finally
{
   System.out.println("Bye! ");
}
   
}




public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        UserRegistration ur=new UserRegistration();
        System.out.println("Enter username and country:  ");
        String un=sc.nextLine();
       String uc=sc.nextLine();
        ur.registerUser(un,uc);
       


}
}

















