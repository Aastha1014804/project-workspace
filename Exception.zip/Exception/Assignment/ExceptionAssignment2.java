import java.util.Scanner;
class ExceptionAssignment2
{
   public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a size of array: ");
        int s=sc.nextInt();
        int a[]=new int[s];
        try{
       System.out.println("Enter the elements of array: ");
       for(int i=0;i<s;i++)
       {
         a[i]=sc.nextInt();
       
       }
       System.out.println("Enter the index of the array you want  to access");
       int in=sc.nextInt();
       System.out.println("The array element at index " + in + " = " + a[in]);
       System.out.println("The array element successfully accessed. ");
}

catch(Exception e)
{
System.out.println(e);
}
}
}

















