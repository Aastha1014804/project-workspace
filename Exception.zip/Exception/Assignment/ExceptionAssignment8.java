import java.util.Scanner;

class ExceptionAssignment8
{
   public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two integer : ");
        
        int a=sc.nextInt();
        int b=sc.nextInt();
       try{ 
        int c=a/b;
        System.out.println("The Quotient of " + a +"/" + b +"=" + c);

   
}
catch(Exception e)
{
  System.out.println("DivideByZeroException Caught ");

}
finally{
System.out.println("Inside Finally block ");

}
}

}















