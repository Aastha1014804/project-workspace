import java.util.Scanner;
class MathOperation
{
   public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a size of array: ");
        int s=sc.nextInt();
        int a[]=new int[s];
int sum=0;
int avg=0;
        try{
       System.out.println("Enter the elements of array: ");
       for(int i=0;i<s;i++)
       {
         a[i]=Integer.parseInt(sc.next());
          sum=sum+a[i];
       }
      avg=sum/s;
       System.out.println("The sum of array element is: " + sum);
       System.out.println("The average of array element. " + avg);
}

catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("java.lang.ArrayIndexOutOfBoundsException ");
}
catch(NumberFormatException ne)
{
System.out.println("NumberFormatException");
}
}
}

















