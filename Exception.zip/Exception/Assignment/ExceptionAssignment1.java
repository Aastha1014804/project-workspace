import java.util.Scanner;
class ExceptionAssignment1
{
   public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a integer: ");
        String s=sc.nextLine();
        
        try{
       int i=Integer.parseInt(s);
        int sq=i*i;
       System.out.println("Square of a integer: " + sq);

}

catch(Exception e)
{
System.out.println("Entered input is not valid format for an integer: ");
}
}
}

















