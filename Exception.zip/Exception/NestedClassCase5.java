class Outer
{
	int a=10;
   static void show1()
   {
      System.out.println("Hello outer method");
   }
     static class Inner
   {
	    void show()
   {
	   System.out.println("Inner show method " );
	   show1();
   }
   }
 }
 public class NestedClassCase5
 {
	 public static void main(String args[])
	 {
		
		 Outer.Inner oi=new Outer.Inner();
		 oi.show();
	 }
 }
 
 //modifier private not allowed in  outer