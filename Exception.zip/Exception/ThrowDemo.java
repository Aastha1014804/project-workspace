import java.util.Scanner;

class VoteEligibility extends RuntimeException
{
    VoteEligibility(String s)
     {
         super(s);
}

}

class ThrowDemo
{
   public static void main(String args[])
 {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter age: ");
        
int a=sc.nextInt();
       try{ 
        if(a<18)
        {
        throw new VoteEligibility("You are not eligible for voting");
       }
       else{
        System.out.println("You are eligible: ");
     }  
   
}
catch(VoteEligibility e)
{
  e.printStackTrace();
}
System.out.println("Normal Termination ");

}
}

















