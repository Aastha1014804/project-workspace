class Outer
{
   
   static class Inner
   {
	    void show()
   {
	   System.out.println("Outer show");
   }
   }
 }
 public class OuterDemoWithStatic
 {
	 public static void main(String args[])
	 {
		 //Outer o=new Outer();
		 //o.show();  cannot find the symbol
		 Outer.Inner oi=new Outer.Inner();
		 oi.show();
	 }
 }