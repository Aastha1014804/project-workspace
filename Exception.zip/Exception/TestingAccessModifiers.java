import testPackage.Foundation;
class Test
{
  public static void main(String args[])
  {
     Foundation f=new Foundation();
	 System.out.println(f.show());
     
  }
}