import java.io.FileInputStream;
class ExceptionChecked
{
   public static void main(String args[])
    {
       try
      {
        FileInputStream f=new FileInputStream("C:/xyz.txt");
       }  

      catch(Exception e)  
       {
        System.out.println(e);
      }
   
     System.out.println("bye");
     
    }
}