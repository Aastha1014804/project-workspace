class ExceptionDemo
{
   public static void main(String args[])
    {
     System.out.println("Yash");
     System.out.println("Technologies");
     System.out.println("Aastha");
     System.out.println(100/0);
     System.out.println("Bye");
    }
}