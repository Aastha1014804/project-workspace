import java.io.*;

public class IOAssignment2 {
    public static void main(String[] args)
        throws IOException
    {
        File f = new File("d:/yash/combine.txt");
        FileInputStream fi = new FileInputStream(f);
        InputStreamReader is = new InputStreamReader(fi);
        BufferedReader bufferedReader = new BufferedReader(is);
  
  
    
        String line;
       
        int totalVowelCount = 0;
		int aCount = 0;
		int eCount = 0;
		int iCount = 0;
		int oCount = 0;
		int uCount = 0;
	
        while ((line = bufferedReader.readLine()) != null) {
            
                 if(line.equals("a") || line.equals("e") || line.equals("i") || line.equals("o") || line.equals("u"))
                
				{
					totalVowelCount += line.length();
			       if(line.equals("a"))
					   aCount++;
				   else if(line.equals("e"))
					   eCount++;
				   else if(line.equals("i"))
					   iCount++;
				   else if(line.equals("o"))
					   oCount++;
				   else
					   uCount++;
				}
                
            }

        System.out.println("Total number of vowel occurence is  = " + totalVowelCount);
		System.out.println("Total number of a occurence is  = " + aCount );
		System.out.println("Total number of e occurence is  = " + eCount );
		System.out.println("Total number of i occurence is  = " + iCount);
		System.out.println("Total number of o occurence is  = " + oCount);
		System.out.println("Total number of  u occurence is  = " + uCount);
		

    }
}