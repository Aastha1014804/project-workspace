import java.io.*;    
public class DataInputOutputDemo 
{  
  public static void main(String[] args) throws IOException 
  {  
   DataOutputStream dos = new DataOutputStream(new FileOutputStream("d:/abc.txt"));
      dos.writeUTF("hello welcome to yash tech: ");
       FileInputStream f=new FileInputStream("d:/abc.txt");
     
      DataInputStream di = new DataInputStream(f);

      while(di.available()>0) {
         String s = di.readUTF();
         System.out.print(s+" "); 
    }  
  }  
}  