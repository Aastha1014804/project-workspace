import java.io.*;
import java.util.Scanner;
class Emply implements Serializable
{
    private double salary;
	private String name,department,designation;
	public void setter(String n,String dpt,String dgn,double sal)
	{
		name=n;
		department=dpt;
		designation=dgn;
		salary=sal;
	}
	
	
	public String toString()
	{
		return name + " " + department + " " + designation + " " + salary;
	}
}

class EmployeeAssignment1
{
	public static void main(String ars[]) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name , department and designation: ");
		String n=sc.nextLine();
		String dpt=sc.nextLine();
		String dsg=sc.nextLine();
		System.out.println("Enter salary: ");
		double sal=sc.nextDouble();
		
		
		Emply e=new Emply();
		e.setter(n,dpt,dsg,sal);
		File f=new File("d:/yash/xyz.txt");
		
	
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
	
		
		e=(Emply)ois.readObject();
		ois.close();
		System.out.println(e);
		
	}
}