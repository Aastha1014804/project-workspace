import java.io.*;
  
public class IOAssignment1 {
    public static void main(String[] args)
        throws IOException
    {
        File f = new File("d:/abc.txt");
        FileInputStream fi = new FileInputStream(f);
        InputStreamReader is = new InputStreamReader(fi);
        BufferedReader bufferedReader = new BufferedReader(is);
  
        String line;
        int wordCount = 0;
        int characterCount = 0;
        int spaceCount = 0;
        int lineCount = 0;
  
        while ((line = bufferedReader.readLine()) != null) {
            
            
                characterCount += line.length();
                String words[] = line.split("\\s+");
                wordCount += words.length;
                spaceCount += wordCount - 1;
                String sentence[] = line.split("[!?.:]+");
                lineCount += sentence.length;
            
        }
        
        
        System.out.println("Total word count = " + wordCount);
        System.out.println("Total number of line = " + lineCount);
        System.out.println("Total number of characters = " + characterCount);
        System.out.println("Total number of spaces = " + spaceCount);
    }
}