import java.io.ByteArrayInputStream;

public class ByteArrayInputDemo 
{
  public static void main(String[] args) {

    // Creates an array of byte
    byte[] b = {1,4,6,8,3,7};

    try {
      ByteArrayInputStream in = new ByteArrayInputStream(b);

      for(int i= 0; i < b.length; i++) {

        int c = in.read();
        System.out.print(c + ", ");
      }
      in.close();
    }

    catch(Exception e) {
      System.out.println(e);
    }
  }
}