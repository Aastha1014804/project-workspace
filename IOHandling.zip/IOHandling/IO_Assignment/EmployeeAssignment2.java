import java.io.*;
class Employee implements Serializable
{
	double salary;
	String name;
	String department;
	String designation;
	Employee(String name,String department,String designation,double salary)
	{    
	    this.salary=salary;
		this.name=name;
		this.department=department;
		this.designation=designation;
		
		
		
	}
	public String tostring()
	{
		return salary+ "" + name + " " +department + " " +designation;
	}
}
class EmployeeAssignment2
{
	public static void main(String[] args) throws Exception
	{
		Employee e= new Employee("Ram","IT","Manager",567.0);
		System.out.println(e);
		File f=new File("d:/yash/File3.txt");
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));//FileInputStream to read input from file
		Employee emp=(Employee)ois.readObject();
		ois.close();
		System.out.println(emp);
	}
}