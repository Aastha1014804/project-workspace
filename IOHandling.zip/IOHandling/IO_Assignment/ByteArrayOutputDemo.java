import java.io.*;  
class ByteArrayOutputDemo
 {  
public static void main(String args[])throws Exception
{    
      FileOutputStream f1=new FileOutputStream("d:/yash/abc.txt");    
      FileOutputStream f2=new FileOutputStream("d:/yash/xyz.txt");    
        
      ByteArrayOutputStream b=new ByteArrayOutputStream();    
      b.write(80);    
      b.writeTo(f1);    
      b.writeTo(f2);    
        
      b.flush();     
      b.close();   
      
     }    
    }   