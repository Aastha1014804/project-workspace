mport java.io.*;
import java.util.Scanner;
public class IOAssignment3 {
    public static void main(String[] args)
        throws IOException
    {
        File f = new File("d:/abc.txt");
        FileInputStream fi = new FileInputStream(f);
        InputStreamReader is = new InputStreamReader(fi);
        BufferedReader bufferedReader = new BufferedReader(is);
  
  
        Scanner sc=new Scanner(System.in);
        String line;
       
        int characterCount = 0;
		
		System.out.println("Enter the file name ");
		System.out.println("Enter the character to be counted: ");
        String c=sc.nextLine();
        while ((line = bufferedReader.readLine()) != null) {
            
                 if(line.equals(c))
                characterCount += line.length();
                
            }

        System.out.println("Total number of given character occurence is  = " + characterCount);

    }
}