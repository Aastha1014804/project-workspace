import java.io.*;
import java.io.ObjectInputStream; 
class Employee implements Serializable
{
    int empid;
	String empName;
	Employee(int empid,String empName)
	{
		this.empid=empid;
		this.empName=empName;
	}
	public String toString()
	{
		return empid + " " + empName;
	}
}

class EmployeeObjectInputDemo
{
	public static void main(String ars[]) throws Exception
	{
		//Employee e=new Employee(27,"Jay");
		//System.out.println(e);
		File f=new File("d:/yash/xyz.txt");
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
	
		
		Employee e=(Employee)ois.readObject();
		ois.close();
		System.out.println(e);
		//ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		//oos.writeObject(e);
		//oos.close();
	}
}