
public class EnumWeek
{

enum Week{
   MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
   }
   
   

public static void main(String args[])
{    
     
      Week w=Week.MONDAY;
	  switch(w)
	  {
	    case MONDAY:
		System.out.println(Week.valueOf("MONDAY"));
		System.out.println("Index of: "+Week.valueOf("MONDAY").ordinal());
	     break;
		case TUESDAY:
		System.out.println(Week.valueOf("TUESDAY"));
		System.out.println("Index of: "+Week.valueOf("TUESDAY").ordinal());
		break;
		case WEDNESDAY:
		System.out.println(Week.valueOf("WEDNESDAY"));
		System.out.println("Index of: "+Week.valueOf("WEDNESDAY").ordinal());
		break;
		case THURSDAY:
		System.out.println(Week.valueOf("THURSDAY"));
		System.out.println("Index of: "+Week.valueOf("THURSDAY").ordinal());
		break;
		case FRIDAY:
		System.out.println(Week.valueOf("FRIDAY"));
		System.out.println("Index of: "+Week.valueOf("FRIDAY").ordinal());
		break;
		case SATURDAY:
		System.out.println(Week.valueOf("SATURDAY"));
		System.out.println("Index of: "+Week.valueOf("SATURDAY").ordinal());
		break;
		case SUNDAY:
		System.out.println(Week.valueOf("SUNDAY"));
		System.out.println("Index of: "+Week.valueOf("SUNDAY").ordinal());
		break;
    
	  }
	   }
	   }