
public class EnumOrdinalDemo
{

enum Directions{
   EAST,WEST,NORTH,SOUTH;
   
   }

public static void main(String args[])
{
    //Directions d=Directions.EAST;
	//System.out.println(d);  //EAST
	for(Directions d:Directions.values())
	{
	   System.out.println(d);
	   }
	   
	   System.out.println("Values of: "+Directions.valueOf("WEST"));
	   System.out.println("Index of: "+Directions.valueOf("NORTH").ordinal());
	   }
	   }