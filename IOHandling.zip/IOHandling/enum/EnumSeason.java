
public class EnumSeason
{

enum Seasons{
   SUMMER("Summer Season"),WINTER("Winter Season"),SPRING("Spring Season"),RAINY("Rainy Season");
   
   String s;
   Seasons(String s)
   {
     this.s=s;
   }
   public String getSeason()
   {
     return s;
   }
   }

public static void main(String args[])
{
    Seasons ss=Seasons.WINTER;
	
	   System.out.println(ss.getSeason());
	   
	   }
	   }