
public class EnumDemo
{

enum Directions{
   EAST(10),WEST(20),NORTH(79),SOUTH(56);
   int val;
   Directions(int val)
   {
     this.val=val;
   }
   }

public static void main(String args[])
{
    //Directions d=Directions.EAST;
	//System.out.println(d);  //EAST
	for(Directions d:Directions.values())
	{
	   System.out.println(d + " " + d.val);
	   }
	   }
	   }