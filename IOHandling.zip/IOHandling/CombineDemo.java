import java.io.*;

class CombineDemo
{
    public static void main(String args[]) throws IOException
	{
	     
		 
     	FileInputStream f1=new FileInputStream("d:/yash/abc.txt");
		FileInputStream f2=new FileInputStream("d:/yash/xyz.txt");
		SequenceInputStream st=new SequenceInputStream(f1,f2);
		FileOutputStream fo=new FileOutputStream("d:/yash/combine.txt");
		
		 int c;
	  while((c=st.read())!=-1)
		  fo.write(c);
		
		st.close();
		f1.close();
		f2.close();
	
		
		  }
		  }