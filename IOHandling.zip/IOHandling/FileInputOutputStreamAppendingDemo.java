import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class FileInputOutputStreamAppendingDemo
{
  public static void main(String args[]) throws IOException
  {
      
	  FileInputStream in=new FileInputStream("d:/yash/File1.txt");
	  FileOutputStream o=new FileOutputStream("d:/yash/File2.txt", true); //appendind
	  int c;
	  while((c=in.read())!=-1)
		  {
		  o.write(c);
		  System.out.print((char)c);
		  }
	  in.close();
	  o.close();
  }
}