import java.io.*;
class Employee implements Serializable
{
    int empid;
	String empName;
	Employee(int empid,String empName)
	{
		this.empid=empid;
		this.empName=empName;
	}
	public String toString()
	{
		return empid + " " + empName;
	}
}

class EmployeeObjectOutputDemo
{
	public static void main(String ars[]) throws IOException
	{
		Employee e=new Employee(27,"Jay");
		System.out.println(e);
		File f=new File("d:/yash/xyz.txt");
		
		
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	}
}