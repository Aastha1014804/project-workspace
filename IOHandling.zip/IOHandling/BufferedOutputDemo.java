import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
    public static void main(String args[])
	{
	     try
{
		 
     	FileOutputStream f=new FileOutputStream("d:/yash/xyz.txt");
		BufferedOutputStream b=new BufferedOutputStream(f);
		String s="Hello welcome to yash tech:";
		byte ba[]=s.getBytes();
		b.write(ba);
		b.close();
	
		}
		catch(Exception e)
		{ 
		  e.printStackTrace();
		  }
		  }
		  }