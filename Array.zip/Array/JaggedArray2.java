class JaggedArray2 {

    public static void main(String[] args)
    {
        int[][] a; 
        System.out.println(a);
        System.out.println(a[0]);
        System.out.println(a[0][0]);
        System.out.println(a.length);
        System.out.println(a[0][0].length);
    }
}