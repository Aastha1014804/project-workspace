class SumOfNumberExcluding67{

    public static void main(String[] args)
    {   
        
        int[] a={10,3,6,1,2,7,9};
        int x=0, y=0;
int s=0;
int s1=0;
    
            for(int i=0; i<7;i++)
         { 
            s=s+a[i];
}
         for(int k=0; k<7; k++)
{
           if(a[k]==6)
            {
             for(int j=k; j<7; j++)
              {
                 s1=s1+a[j];
                 if(a[j]==7)
                   break;
                 }
       }
    }
     System.out.println("Sum is " + s-s1-7);
        
      
       
        }
         }
