class Sorting{

    public static void main(String[] args)
    {   
        
        int[] a={10,2,7,1,3,8,4};
        int temp=0;
    
            for(int i=0; i<6;i++)
         { 
           for(int j=0; j<7-i-1; j++){
           if(a[j]>a[j+1])
            {
             temp =a[j];
             a[j]=a[j+1];
             a[j+1]= temp;
           }
           }
}

        for(int k:a){
        System.out.println(k + " ");
       
        }
         }
}