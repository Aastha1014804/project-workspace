class OneDArrayAverage{

    public static void main(String[] args)
    {   
        
        int[] a={1,2,3};
        
         int t=0;
         
            for(int i:a)
         {
            t=t+i;
           }
           
        System.out.println("sum is: " + t);
        System.out.println("average is " + t/3 );
        
        
    }
}