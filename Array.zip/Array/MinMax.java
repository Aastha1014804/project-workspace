class MinMax{

    public static void main(String[] args)
    {   
        
        int[] a={10,2,7,1,3,8,4};
        
        int max=0;
        int min=a[0];
            for(int i:a)
         {
           if(max<i)
            max=i;
           if(min>i)
             min=i;
           }
           
        System.out.println("Maximum value" + max);
        System.out.println("Minimum value is " + min);
        
        
    }
}