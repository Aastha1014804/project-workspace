class TwoDArrayAverage{

    public static void main(String[] args)
    {   
        
        int[][] a={{1,2,3},{4,5}};
        
int t=0;
         for(int ir[]:a)
          {
            for(int i:ir)
         {
            t=t+i;
           }
           }
        System.out.println("sum is: " + t);
        System.out.println("average is " + t/5 );
        
        
    }
}