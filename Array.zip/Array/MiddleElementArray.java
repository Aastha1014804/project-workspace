class MiddleElementArray{

    public static void main(String[] args)
    {   
        
        int[] a={10,3,6};
        int[] b={1,2,7};
        int[] c=new int[2];
        
        c[0]=a[1];
        c[1]=b[1];
     for(int i:c)
     System.out.print( i + " ");
        
      
       
        }
         }