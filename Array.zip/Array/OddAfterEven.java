class OddAfterEven{

    public static void main(String[] args)
    {   
        
        int[] a={10,3,6,1,2,7};
       
        int[] c=new int[6];
        int j=0;
        
       for(int i=0;i<6; i++)
       {
           if(a[i]%2==0)
             c[j++]=a[i];
         }
        for(int k=0;k<6; k++)
       {
           if(a[k]%2!=0)
             c[j++] = a[k];
         }

     for(int m:c)
     System.out.print( m + " ");
        
      
       
        }
         }