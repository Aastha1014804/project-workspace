class 2DArrayAverage{

    public static void main(String[] args)
    {   
        
        int[][] a=new int[2][3];
         for(int ir:a)
          {
            for(int i:ir)
         {
            t=t+i;
           }
           }
        System.out.println("sum is: " + t);
        System.out.println("average is " +t/5 );
        
        
    }
}