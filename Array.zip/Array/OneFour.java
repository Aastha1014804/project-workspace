class OneFour{

    public static void main(String[] args)
    {   
        
        int[] a={10,2,7,1,3,8,4};
        int count=0;
    
            for(int i=0; i<6;i++)
         { 
          
           if(a[i]==4 || a[i]==1)
            {
             count++;
           }
}

        if(count==7)
        System.out.println("True ");
        else
         System.out.println("False");
      
       
        }
         }
