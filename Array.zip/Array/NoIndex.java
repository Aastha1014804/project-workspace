class NoIndex{

    public static void main(String[] args)
    {   
        
        int x=Integer.parseInt(args[0]);
        int[] a={10,2,7,1,3,8,4};
        int index=-1;
        
    
            for(int i=0; i<7;i++)
         {
           if(x==a[i])
            index=i;
           
           }
           
        System.out.println("value fount at index = " + index);
       
        
         }
}