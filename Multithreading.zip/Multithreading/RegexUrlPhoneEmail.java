import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexUrlPhoneEmail {
  public static void main(String[] args) {
	System.out.println(Pattern.matches("[0-9]{10}","7694955651"));
	
	System.out.println(Pattern.matches("[a-zA-z0-9]{5,}[@]{1}[a-z]{5,}[.]{1}[a-z]{3}","aastha@gmail.com"));
	
    System.out.println(Pattern.matches("(https://)(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?","https://www.google.com"));
    System.out.println(Pattern.matches("[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}","17/07/1999"));
   
  }
}