class BookTicket
{
  int totalSeats=12;
  void booksSeat(int seats)
  {
    if(totalSeats>=seats)
	{
	   System.out.println("Booked Successfully: ");
	  totalSeats=totalSeats-seats;
	  System.out.println("Remaining seats: " + totalSeats);
	}
	else{
	  System.out.println("seats are not available "+ totalSeats);
	}
  }
}
class TicketWithoutSynchro extends Thread
{
    static BookTicket b;
	int seats;
    public void run()
	{
	  b.booksSeat(seats);
	}
	public static void main(String args[])
      {
	    b=new BookTicket();
		TicketWithoutSynchro p1=new TicketWithoutSynchro();
		p1.seats=8;
		p1.starts();
		
		TicketWithoutSynchro p2=new TicketWithoutSynchro();
		p2.seats=10;
		p2.starts();
	  }
}