
class ThreadDemo2 implements Runnable
{
   public void run()
   {
      System.out.println("Thread started");
   }
   
   public static void main(String args[])
   {
       //ThreadDemo2 t=new ThreadDemo2();
	   Thread t=new Thread(new ThreadDemo2());
	   t.start();
   }
   
  }