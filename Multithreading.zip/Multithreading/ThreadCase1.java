//single task using single thread 
import java.lang.Thread;
class ThreadCase1 extends Thread
{
   public void run()
   {
      System.out.println("Thread started");
   }
   
   public static void main(String args[])
   {
       ThreadCase1 t=new ThreadCase1();
	   t.start();
   }
   
  }