class ThreadisAliveMethodDemo extends Thread
 {
   public void run()
   {
       Thread.currentThread().setName("Run");
       System.out.println("Run: " + Thread.currentThread().getName());
   }


  public static void main(String args[])
  {
      System.out.println(Thread.currentThread().getName());
	  ThreadisAliveMethodDemo t1=new ThreadSetGetNmaeMethodDemo2();
	  System.out.println(t1.isAlive()); //false
	  t1.setName("T1 Thread");
	  t1.start();
	  System.out.println(t1.isAlive()); //true
	  System.out.println(Thread.currentThread().isAlive()); true
	  
	  }
  }