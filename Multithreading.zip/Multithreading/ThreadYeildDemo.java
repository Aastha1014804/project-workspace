class ThreadYeildDemo extends Thread
 {
    public void run()
      {
  
		  for(int i=1;i<=3;i++)
		  {
		   Thread.yield();
		   System.out.println("run thread" + i);
		   
		  }

   }
	

  public static void main(String args[]) throws Exception
  {
  
     ThreadYeildDemo ty=new ThreadYeildDemo();
	  
	  ty.start();

		  for(int i=1;i<=3;i++)
		  {
		   System.out.println("main thread" + i);

		  }
     
	
	  }
  }