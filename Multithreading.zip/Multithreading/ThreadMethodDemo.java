class ThreadMethodDemo
{
  public static void main(String args[])
  {
      System.out.println(Thread.currentThread().getName());
	  Thread.currentThread().setName("Yash");
	  System.out.println(Thread.currentThread().getName());
  }