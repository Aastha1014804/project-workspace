class ThreadInterruptedDemo extends Thread
{
   public void run()
   {  
   
   
   System.out.println(Thread.interrupted());
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(2000);
		  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo tid=new ThreadInterruptedDemo();
		tid.start();
		tid.interrupt();
	 }
}

// true 1 2 3