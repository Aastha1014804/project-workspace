class ThreadInterruptedDemo7 extends Thread
{
   public void run()
   {  
   
 
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(2000);
			   System.out.println(Thread.interrupted());
              System.out.println(Thread.currentThread().isInterrupted());
		  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo7 tid=new ThreadInterruptedDemo7();
		tid.start();
		tid.interrupt();
	 }
}

//op=  true 1 sleep interrupted