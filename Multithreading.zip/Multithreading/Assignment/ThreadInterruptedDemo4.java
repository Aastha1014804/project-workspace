class ThreadInterruptedDemo4 extends Thread
{
   public void run()
   {  
   
   System.out.println(Thread.interrupted()); //true
   System.out.println(Thread.interrupted()); //false
   System.out.println(Thread.interrupted()); 
  
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(1000);
			}
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo4 tid=new ThreadInterruptedDemo4();
		tid.start();
		tid.interrupt();
	 }
}

//op=  true false false 1 2 3