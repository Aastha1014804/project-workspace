class ThreadInterruptedDemo3 extends Thread
{
   public void run()
   {  
   
   
   //System.out.println(Thread.interrupted());
   System.out.println(Thread.currentThread().isInterrupted());
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(2000);
			 
		  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo3 tid=new ThreadInterruptedDemo3();
		tid.start();
		tid.interrupt();
	 }
}

//op=  true 1 sleep interrupted 2 3