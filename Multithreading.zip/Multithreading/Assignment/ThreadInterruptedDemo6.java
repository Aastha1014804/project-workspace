class ThreadInterruptedDemo6 extends Thread
{
   public void run()
   {  
   
   System.out.println(Thread.interrupted()); //true
  
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(2000);
			   System.out.println(Thread.interrupted());
              //System.out.println(Thread.currentThread().isInterrupted());
		  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo6 tid=new ThreadInterruptedDemo6();
		tid.start();
		tid.interrupt();
	 }
}

//op=  true 1 sleep interrupted