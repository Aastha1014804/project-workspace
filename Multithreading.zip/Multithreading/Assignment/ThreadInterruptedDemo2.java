class ThreadInterruptedDemo2 extends Thread
{
   public void run()
   {  
   
   
   System.out.println(Thread.interrupted());
   System.out.println(Thread.currentThread().isInterrupted());
   
         try{
			 for(int i=1;i<=3;i++)
		  {
			  System.out.println(i);
			  Thread.sleep(2000);
		    }
		 }
	     catch(Exception e)
	     {
		   System.out.println(e);
	     }
	  
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo2 tid=new ThreadInterruptedDemo2();
		tid.start();
		tid.interrupt();
	 }
}

// op = true false 1 2 3