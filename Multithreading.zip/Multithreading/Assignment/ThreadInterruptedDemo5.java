class ThreadInterruptedDemo5 extends Thread
{
   public void run()
   {  
   
   //System.out.println(Thread.interrupted()); //true
   //System.out.println(Thread.interrupted()); //false
   //System.out.println(Thread.interrupted()); 
   System.out.println(Thread.currentThread().isInterrupted());
   System.out.println(Thread.currentThread().isInterrupted());
      for(int i=1;i<=3;i++)
		  {
      try{
			  System.out.println(i);
			  Thread.sleep(2000);
			   //System.out.println(Thread.interrupted());
              //System.out.println(Thread.currentThread().isInterrupted());
		  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  }
   }

    public static void main(String args[])
	{ 
	    ThreadInterruptedDemo5 tid=new ThreadInterruptedDemo5();
		tid.start();
		tid.interrupt();
	 }
}

//op=  true 1 sleep interrupted