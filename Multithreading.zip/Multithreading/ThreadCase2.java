//single task using multiple thread 
import java.lang.Thread;
class ThreadCase2 extends Thread
{
   public void run()
   {
      System.out.println("Thread started");
   }
   
   public static void main(String args[])
   {
       ThreadCase2 t1=new ThreadCase2();
	   t1.start();
	   ThreadCase2 t2=new ThreadCase2();
	   t2.start();
   }
   
  }