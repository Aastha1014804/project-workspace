class ThreadPriorityDemo extends Thread
 {
   public void run()
   {
       System.out.println("In Run method: ");
	   System.out.println(Thread.currentThread().getPriority());
   }


  public static void main(String args[])
  {
      System.out.println(Thread.currentThread().getPriority()); //5
	  //Thread.currentThread().setPriority(10);
	  Thread.currentThread().setPriority(MIN_PRIORITY);
	  System.out.println(Thread.currentThread().getPriority());
	  ThreadPriorityDemo tp=new ThreadPriorityDemo();
      tp.setPriority(7);
	  tp.start();
	   //tp.setPriority(20); IllegalArgumentException
	  }
  }