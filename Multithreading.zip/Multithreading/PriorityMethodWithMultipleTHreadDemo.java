class PriorityMethodWithMultipleTHreadDemo extends Thread
 {
 public void run()
 {
     for(int i=1;i<=3;i++)
	   {
	   try{
	      //Thread.sleep(100);
	      System.out.println(Thread.currentThread().getName());
		}
	 catch(Exception e)
	  {
	    e.printStackTrace();
	  }
	  
	   System.out.println(i);
	}
 }

  public static void main(String args[]) throws Exception
  {
     PriorityMethodWithMultipleTHreadDemo ts=new PriorityMethodWithMultipleTHreadDemo();
	  ts.setName("Yash");
	  ts.setPriority(10);
	  ts.start();
     
	 PriorityMethodWithMultipleTHreadDemo ts1=new PriorityMethodWithMultipleTHreadDemo();
	 ts1.setName("Aastha");
	 ts1.setPriority(1);
	 ts1.start();
	  }
  }