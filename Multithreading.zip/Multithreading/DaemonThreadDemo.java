class DaemonThreadDemo extends Thread
 {
 public void run()
 {
   
	      System.out.println(""Run method);
		  if(Thread.currentThread().isDaemon())
		  {
		   System.out.println("I'm in Daemon method");
		  }
		  else
		  {
		    System.out.println("I'm not  in Daemon method");
		  }
   }
	

  public static void main(String args[]) throws Exception
  {
  
    System.out.println(""Main method);
     DaemonThreadDemo td=new DaemonThreadDemo();
	  ts.setDaemon(true);
	  td.start();
     
	
	  }
  }