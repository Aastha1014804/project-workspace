

public class NotifyAllDemo
{
   public static void main(String args[])
    {
	    Test t=new Test();
		t.start();
		synchronized(t)
		{
		  System.out.println(" Calling wait method");
		  t.wait();
		  System.out.println(" Main thread got notified .");
		}
	}
}

class Test extends Thread
{
    public void run()
	{
	    synchronized(this)
		{
		 for(int i=0;i<3;i++)
		 {
		    System.out.println(i);
		 }
		 System.out.println("Child thread sending notification. ");
		 this.notifyAll();
		}
	}
}