class GetStateMethod extends Thread
{
   public void run()
   {
     Thread.State s=Thread.currentThread().getState();
	 System.out.println("Thread state is :  " + s);
   }
   
   public static void main(String args[])
   {
     GetStateMethod g=new GetStateMethod();
	 g.start();
}
}