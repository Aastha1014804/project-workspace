class BookTicket
{
  int totalSeats=12;
  synchronized void booksSeat(int seats)
  {
    if(totalSeats>=seats)
	{
	   System.out.println("Booked Successfully: ");
	  totalSeats=totalSeats-seats;
	  System.out.println("Remaining seats: " + totalSeats);
	}
	else{
	  System.out.println("seats are not available "+ totalSeats);
	}
  }
}
class TicketWithSynchronizedMethod extends Thread
{
    static BookTicket b;
	int seats;
    public void run()
	{
	  b.booksSeat(seats);
	}
	public static void main(String args[])
      {
	    b=new BookTicket();
		TicketWithSynchronizedMethod p1=new TicketWithSynchronizedMethod();
		p1.seats=8;
		p1.starts();
		
		TicketWithSynchronizedMethod p2=new TicketWithSynchronizedMethod();
		p2.seats=10;
		p2.starts();
	  }
}