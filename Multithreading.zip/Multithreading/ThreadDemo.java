import java.lang.Thread;
class ThreadDemoUsingThreadClass extends Thread
{
   public void run()
   {
      System.out.println("Thread started");
   }
   
   public static void main(String args[])
   {
       ThreadDemoUsingThreadClass t=new ThreadDemoUsingThreadClass();
	   t.start();
   }
   
  }