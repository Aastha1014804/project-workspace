class ThreadSetGetNmaeMethodDemo2 extends Thread
 {
   public void run()
   {
       Thread.currentThread().setName("Run");
       System.out.println("Run: " + Thread.currentThread().getName());
   }


  public static void main(String args[])
  {
      System.out.println(Thread.currentThread().getName());
	  ThreadSetGetNmaeMethodDemo2 t1=new ThreadSetGetNmaeMethodDemo2();
	  t1.setName("T1 Thread");
	  t1.start();
	  ThreadSetGetNmaeMethodDemo2 t2=new ThreadSetGetNmaeMethodDemo2();
	  t2.setName("T2 Thread");
	  t2.start();
	  }
  }