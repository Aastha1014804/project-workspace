class SleepMethodWithTHreadDemo extends Thread
 {
 public void run()
 {
     for(int i=1;i<=3;i++)
	   {
	   try{
	      Thread.sleep(6000);
	      //Thread.sleep(-1); interrupted exception
		}
	 catch(Exception e)
	  {
	    e.printStackTrace();
	  }
	  
	   System.out.println(i);
	}
 }

  public static void main(String args[]) throws Exception
  {
      SleepMethodWithTHreadDemo ts=new SleepMethodWithTHreadDemo();
	  ts.start();
     
	  }
  }