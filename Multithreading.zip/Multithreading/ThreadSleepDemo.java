class ThreadSleepDemo 
 {

  public static void main(String args[]) throws Exception
  {
       try
	   {
	   for(int i=1;i<=3;i++)
	   {
	      Thread.sleep(6000);
	      System.out.println(i);
	   }
	   }
      catch(Exception e)
	  {
	    e.printStackTrace();
	  }
     
	  }
  }