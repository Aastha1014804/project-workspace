class BookTicket
{
  int totalSeats=12;
   void booksSeat(int seats)
  {
  
   //synchronized(object refrencename){}
   synchronized(this){
    if(totalSeats>=seats)
	{
	   System.out.println("Booked Successfully: ");
	  totalSeats=totalSeats-seats;
	  System.out.println("Remaining seats: " + totalSeats);
	}
	else{
	  System.out.println("seats are not available "+ totalSeats);
	}
	}
  }  //object lock
}
class TicketWithSynchronizedBlock extends Thread
{
    static BookTicket b;
	int seats;
    public void run()
	{
	  b.booksSeat(seats);
	}
	public static void main(String args[])
      {
	    b=new BookTicket();
		TicketWithSynchronizedBlock p1=new TicketWithSynchronizedBlock();
		p1.seats=8;
		p1.starts();
		
		TicketWithSynchronizedBlock p2=new TicketWithSynchronizedBlock();
		p2.seats=10;
		p2.starts();
	  }
}