import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ExtractNum{
   public static void main(String[] args) {
      String data = "welcome4563To135Yash496Yash543Technologies";
     
      String regex = "([0-9]+)";
     
      Pattern pattern = Pattern.compile(regex);
      
      Matcher matcher = pattern.matcher(data);
      System.out.println("Digits in the given string are: ");
      while(matcher.find()) {
         System.out.print(matcher.group()+" ");
      }
   }
}