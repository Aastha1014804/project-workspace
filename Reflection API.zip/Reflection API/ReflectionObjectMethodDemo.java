class Test
{
	void show()
	{
		
		System.out.println("Hello Reflection Demo: ");
	}
}

interface Testing
{
	
}

public class ReflectionObjectMethodDemo
{
    public static void main(String args[]) throws Exception
	{
	    Class c1=Class.forName("Test");
		Class c2=Class.forName("Testing");
		System.out.println(c1.getName());
		System.out.println(c1.isInterface());
		System.out.println(c2.isInterface());
		System.out.println(c1.isArray());
		System.out.println(c1.isPrimitive());
	}
}