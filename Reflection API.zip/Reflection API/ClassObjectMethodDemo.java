class Test
{
	void show()
	{
		
		System.out.println("Hello Reflection Demo: ");
	}
}

interface Testing
{
	
}

public class ClassObjectMethodDemo
{
    public static void main(String args[]) throws Exception
	{
	    Class c1=Class.forName("Test");
		Class c2=Class.forName("Testing");
		System.out.println(c1.getName());
		System.out.println(c1.isInterface());
		System.out.println(c2.isInterface());
		
		Class<int[]> c3=int[].class;
		System.out.println(c3.isArray());
		
		Class c4=int.class;
		System.out.println(c4.isPrimitive());
	}
}