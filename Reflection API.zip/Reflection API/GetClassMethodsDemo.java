class Test
{
	void show()
	{
		System.out.println("Hello Reflection Demo: ");
	}
}

class Testing
{
	void display()
	{
		System.out.println("Hello Reflection Demo Testing class : ");
	}
}

public class ReflectionDemo
{
    public static void main(String args[]) throws Exception
	{
	    Class c1=Class.forName("Test");
		System.out.println(c1.getName());
		ReflectionDemo obj=new ReflectionDemo();
		Class c2=obj.getClass();
		System.out.println(c2.getName());
		
		Class c3=Testing.class;
		System.out.println(c3.getName());
		
	}
}