class Test
{}

public class ForNameMethodsDemo
{
    public static void main(String args[]) throws Exception
	{
	    Class c=Class.forName("Test");
		System.out.println(c.getName());
	}
}