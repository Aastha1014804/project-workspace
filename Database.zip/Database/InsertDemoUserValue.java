import java.sql.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class InsertDemoUserValue
{
   public static void main(String args[])
   {
     try{
	   Class.forName("com.mysql.jdbc.Driver");
	   
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   
		   String q="insert into employee(empID,name) values(?,?)";
		   PreparedStatement ps=con.prepareStatement(q);
		   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		   System.out.println("Enter the employee id: ");
		   int i= Integer.parseInt(br.readLine());
		   System.out.println("Enter the employee name: ");
		   String n=br.readLine();
		   ps.setInt(1,i);
		   ps.setString(2,n);
		   ps.executeUpdate();
		   System.out.println("Inserted successfully. ");
		   con.close();
	 }
	 catch(Exception e)
	 {
	   System.out.println(e);
	 }
   }
}