import java.sql.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
class ClobDemo
{
   public static void main(String args[])
   {
     try{
	   Class.forName("com.mysql.jdbc.Driver");
	   
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   
		   String q="insert into Article(id,content) values(?,?)";
		   PreparedStatement ps=con.prepareStatement(q);
		   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		   System.out.println("Enter the product id: ");
		   int i= Integer.parseInt(br.readLine());
		  
			FileReader f=new FileReader("D:\\yash\\File1.txt");
	
		   ps.setInt(1,i);
		   ps.setClob(2, f);
		   ps.execute();
		   System.out.println("Inserted successfully. ");
		   con.close();
	 }
	 catch(Exception e)
	 {
	   System.out.println(e);
	 }
   }
}





