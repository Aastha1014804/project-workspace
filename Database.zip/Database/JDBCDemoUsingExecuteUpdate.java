import java.sql.*;
class JDBCDemoUsingExecuteUpdate
{
   public static void main(String ars[])
   {
	   try
	   {   
	       //step1 loading driver
		   Class.forName("com.mysql.jdbc.Driver");
		   
		   //step2 creating connection
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   if(con!=null)
		   {
			   System.out.println("Connection is created successfully: ");
		   }
		   else
		   {
			  System.out.println("Connection is not created successfully: "); 
		   }
		   //step3 create query
		   String q="select name from employee";
		   Statement st=con.createStatement();
		  
		   st.executeUpdate("update employee set Salary=17000 where empID=1002");
		   //step4 process the data
		    ResultSet set=st.executeQuery(q);
		   while(set.next())
		   {
		   //instead of empID we can write column number(1)
			   String name=set.getString("name"); //(2)
			   System.out.println("Name is: " + name);
		   }
		   // step5 connection close
		    con.close();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
	   }
   }
}