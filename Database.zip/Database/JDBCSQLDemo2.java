import java.sql.*;
class JDBCSQLDemo2
{
   public static void main(String ars[])
   {
	   try
	   {   

		   Class.forName("com.mysql.jdbc.Driver");
		   
		  
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   if(con!=null)
		   {
			   System.out.println("Connection is created successfully: ");
		   }
		   else
		   {
			  System.out.println("Connection is not created successfully: "); 
		   }
	
		   String q="select * from employee where name like '_h%'";
		   Statement st=con.createStatement();
		   ResultSet set=st.executeQuery(q);
		
		   while(set.next())
		   {
			   int id=set.getInt("empID"); //instead of empID we can write column number(1)
			   String name=set.getString("name"); //(2)
			   System.out.println("id " + id + " " + "Name is: " + name);
		   }
		   // step5 connection close
		    con.close();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
	   }
   }
}