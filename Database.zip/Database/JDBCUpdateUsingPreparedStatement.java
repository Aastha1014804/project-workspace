import java.sql.*;
class JDBCUpdateUsingPreparedStatement
{
   public static void main(String ars[])
   {
	   try
	   {   
	
		   Class.forName("com.mysql.jdbc.Driver");
		   
		
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   if(con!=null)
		   {
			   System.out.println("Connection is created successfully: ");
		   }
		   else
		   {
			  System.out.println("Connection is not created successfully: "); 
		   }
		
		
		   String q="select * from employee";
		   PreparedStatement ps=con.prepareStatement("update employee set Salary=17000 where empID=1002");
		 
		   ps.executeUpdate();
		   ResultSet set=ps.executeQuery(q);
		   
	
		   while(set.next())
		   {
		  
			   String name=set.getString("name"); //(2)
			   System.out.println("Name is: " + name);
		   }
		 
		    con.close();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
	   }
   }
}