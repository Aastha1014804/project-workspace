import java.sql.*;
class InsertDemo
{
   public static void main(String args[])
   {
     try{
	   Class.forName("com.mysql.jdbc.Driver");
	   
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   
		   String q="insert into employee(empID,name) values(?,?)";
		   PreparedStatement ps=con.prepareStatement(q);
		   
		   ps.setInt(1,1005);
		   ps.setString(2,"Shyam");
		   ps.executeUpdate();
		   System.out.println("Inserted successfully. ");
		   con.close();
	 }
	 catch(Exception e)
	 {
	   System.out.println(e);
	 }
   }
}