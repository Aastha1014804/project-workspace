import java.sql.*;
class JDBCSQLDemo3
{
   public static void main(String ars[])
   {
	   try
	   {   

		   Class.forName("com.mysql.jdbc.Driver");
		   
		  
		   String url="jdbc:mysql://localhost:3306/yash";
		   String user="root";
		   String pass="root";
		   Connection con=DriverManager.getConnection(url,user,pass);
		   if(con!=null)
		   {
			   System.out.println("Connection is created successfully: ");
		   }
		   else
		   {
			  System.out.println("Connection is not created successfully: "); 
		   }
	
		   String q="select count(*) from employee";
		   Statement st=con.createStatement();
		   ResultSet set=st.executeQuery(q);
		
		   while(set.next())
		   {
			   int id=set.getInt(int);
			  
			   System.out.println(id);
		   }
		   // step5 connection close
		    con.close();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
	   }
   }
}