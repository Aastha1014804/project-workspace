import java.sql.*;
import java.io.*;
class ExtractImagesFromDB
{
	public static void main(String [] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yash","root","root");
			
			PreparedStatement ps=con.prepareStatement("Select * from images");
			
			ResultSet rs=ps.executeQuery();
			
			FileOutputStream fo=new FileOutputStream("NewImg.jpg");
			while(rs.next())
			{
				InputStream fi=rs.getBinaryStream("pic");
				int c;
				
				while((c=fi.read())!=-1)
				{
					fo.write(c);
				}
			}
			
			System.out.println("File saved successfully..");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}