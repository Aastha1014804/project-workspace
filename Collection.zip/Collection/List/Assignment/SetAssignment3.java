import java.util.TreeSet;
import java.util.Iterator;
import java.util.Scanner;
class SetAssignment3
{
    public static void main(String args[])
	{
	  TreeSet<String> t=new TreeSet<String>();
	  Scanner sc=new Scanner(System.in);
	  t.add("Ram");
	  t.add("Rohit");
      t.add("Pinki");
	  t.add("Palak");
	  t.add("Richa");
	  t.add("Mayank");
	  System.out.println();
	  Iterator i=t.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }

	  Iterator<String> it= t.descendingIterator();
	   System.out.println("After Revering the elements are : ");
	   while(it.hasNext())
	  {
		  System.out.println(it.next()); 
	  }
	   System.out.println("Enter the element you want to check whether exist in treeSet or not: ");
	   String s=sc.nextLine();
	   System.out.println(t.contains(s));
	  
	}
}