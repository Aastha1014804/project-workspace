import java.util.HashSet;
import java.util.Iterator;
class SetAssignment2
{
    public static void main(String args[])
	{
	  HashSet<String> h=new HashSet<String>();
	  h.add("Ram");
	  h.add("Rohit");
      h.add("Pinki");
	  h.add("Palak");
	  h.add("Richa");
	  h.add("Mayank");
	  
	  Iterator i=h.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }

	  
	}
}