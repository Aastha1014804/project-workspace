import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
class ListAssignment4
{
    public static void main(String args[])
	{
	  Vector employee=new Vector();
	  employee.add("Ram");
	  employee.add(1014);
	  employee.add(6000.0);
	  
	  
	 //System.out.println(employee);
	
	 System.out.println("Printing using iterator");
	 
	  Iterator i=employee.iterator();
	  while(i.hasNext())
	  {
		  System.out.println(i.next());
	  }
	   
	 Enumeration e=employee.elements();
	 while (e.hasMoreElements()) {

		System.out.println(e.nextElement());
	
	 }
	}
}