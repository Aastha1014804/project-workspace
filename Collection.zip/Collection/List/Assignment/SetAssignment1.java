import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
class SetAssignment1
{
	static HashSet<String> h=new HashSet<>();
	
	static HashSet saveCountryNames(String countryName)
	{
		h.add(countryName);
		return h;
	}
	
	static String getCountry(String countryName2)
	{
		Iterator i=h.iterator();
		while(i.hasNext())
		{
            if((i.next()).equals(countryName2))
			{
				return "Country Found\n";
			}
		}
		return "No country found\n";
	}
	
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
	
		while(true)
		{
			System.out.println("Press 1 to store a city");
			System.out.println("Press 2 to find a city");
			System.out.println("Press 3 to Exit");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1:System.out.println("Please enter the city name :");
				       saveCountryNames(sc.next());
					   System.out.println("City saved successfully!\n");
					   break;
					   
				case 2:System.out.println("Please enter the name of city which you want to find:");
					   System.out.println(getCountry(sc.next()));
					   break;
			}
			if(choice==3)
			{
				break;
			}
		}
	}
}