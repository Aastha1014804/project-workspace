import java.util.ArrayList;
class ArrayListDemo
{
    public static void main(String args[])
	{
	  ArrayList<int> a=new ArrayList<>();
	  a.add(1);
	  a.add(2);
	  a.add(3);
	  a.add(4);
	  a.add(5);
	    System.out.println(a);
	  
	}
}