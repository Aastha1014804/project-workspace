import java.util.Queue;
import java.util.PriorityQueue;
import java.util.Iterator;
class PriorityQueueDemo
{
    public static void main(String args[])
	{
	  Queue<Integer> q=new PriorityQueue<Integer>();
	
	  q.add(200);
	  q.add(300);
      q.add(400);
	  q.add(500);
	  System.out.println(q.remove());  
	  System.out.println(q);
	  Iterator i=t.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }
		  System.out.println(q.size()); 
		  System.out.println(q.peek()); 
		  System.out.println(q.poll()); 

	  Queue<Integer> li=new LinkedList<Integer>();
	  li.add(4);
	  li.add(44);
	  li.add(42);
	  li.add(41);
	  System.out.println(li.size()); 
		  System.out.println(li.peek()); 
		  System.out.println(li.poll()); 
	   li.remove();
	    li.remove();
		  li.remove();
	  
	}
}