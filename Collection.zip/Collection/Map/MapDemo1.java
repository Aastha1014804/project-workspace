import java.util.Queue;
import java.util.Map;
import java.util.Iterator;
class MapDemo1
{
    public static void main(String args[])
	{
	  Map m=new HashMap();
	
	  m.put(20, "yash");
	  m.put(30, "tech");
      m.put(40, "Aastha");
	  Set s=m.entrySet();//convert to set to traverse
	  Iterator i=s.iterator();
	  
	  while(i.hasNext())
	  {
		  Map.Entry e=(Map.Entry)i.next();
		  System.out.println("Key is : " + e.getKey() + "Value" + e.getValue); 
	  }
		
	  
	}
}