import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Iterator;
class MapAssignment3
{
    public static void main(String args[])
	{
	  Map<String,Integer> contactList =new HashMap<String,Integer>();
	  Scanner sc=new Scanner(System.in);
	  contactList.put("Archi",76836);
	  contactList.put("Balu",83456);
      contactList.put("Chetan",93732);
	   System.out.println("Enter the key you want to check present or not .");
	   String k=sc.nextLine();
	   System.out.println(contactList.containsKey(k));
	   
	   System.out.println("Enter the value you want to check present or not .");
	   int v=sc.nextInt();
	   System.out.println(contactList.containsValue(v));
	   Iterator<Entry<String,Integer>> i = contactList.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry<String,Integer> m
                = (Map.Entry<String,Integer>)
                      i.next();
 
            System.out.println(m.getKey() + " = "
                               + m.getValue());
	   }
	}
}