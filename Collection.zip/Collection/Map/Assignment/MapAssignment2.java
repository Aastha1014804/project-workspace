import java.util.Properties;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Iterator;
class MapAssignment2
{
    public static void main(String args[])
	{
	   Properties p = new Properties();
	  p.setProperty("Madhya Pradesh", "Bhopal");
	  p.setProperty("Himachal Pradesh", "Shimla");
      p.setProperty("Chattisgarh", "Raipur");
	  p.setProperty("Maharashtra", "Mumbai");
	  p.setProperty("India", "Delhi");
       Set s=p.entrySet();
	   Iterator i = s.iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry m
                = (Map.Entry)
                      i.next();
 
            System.out.println(m.getKey() + " = "
                               + m.getValue());
	   }
	}
}