import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Iterator;
class MapAssignment1
{
    public static void main(String args[])
	{
	  Map<Integer,String> hm =new HashMap<Integer,String>();
	  Scanner sc=new Scanner(System.in);
	  hm.put(2, "A");
	  hm.put(3, "B");
      hm.put(4, "C");
	   System.out.println("Enter the key you want to check present or not .");
	   int k=sc.nextInt();
	   System.out.println(hm.containsValue("B"));
	   System.out.println(hm.containsKey(k));
	   Iterator<Entry<Integer,String>> i = hm.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry<Integer, String> m
                = (Map.Entry<Integer, String>)
                      i.next();
 
            System.out.println(m.getKey() + " = "
                               + m.getValue());
	   }
	}
}