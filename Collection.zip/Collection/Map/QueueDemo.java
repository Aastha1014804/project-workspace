import java.util.Queue;
import java.util.Iterator;
class QueueDemo
{
    public static void main(String args[])
	{
	  Queue<String> q=new Queue<String>();
	
	  q.add("Ram");
	  q.add("Rohit");
      q.add("Pinki");
	  q.add("Palak");
	  q.add("Richa");
	  q.add("Mayank");
	  System.out.println(q);
	  Iterator i=t.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }
		  System.out.println(q.size()); 
		  System.out.println(q.peek()); 
		  System.out.println(q.pop()); 
		   System.out.println(q.poll()); 
	  
	  
	}
}