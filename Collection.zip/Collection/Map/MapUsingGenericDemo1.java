import java.util.*;
class MapUsingGenericDemo1
{
    public static void main(String args[])
	{
	  Map<Integer,String> m=new HashMap<Integer,String>();
	
	  m.put(20, "yash");
	  m.put(30, "tech");
      m.put(40, "Aastha");
	 for(Map.Entry ma:m.entrySet())
	 {
	    System.out.println("zkey: " + ma.getKey() + "Value: " + ma.getValue());
	 }
	  Collection.sort(m);
	  
		for(Map.Entry ma:m.entrySet())
	 {
	    System.out.println("zkey: " + ma.getKey() + "Value: " + ma.getValue());
	 }
	  
	}
}