import java.util.Vector;
import java.util.Iterator;
class VectorDemo
{
    public static void main(String args[])
	{
	  Vector<String> v=new Vector<String>();
	  v.add("Jan");
	  v.add("Feb");
      v.add("March");
	  v.add("April");
	  
	  System.out.println(v); 
	
	  v.add("Yash");
	  System.out.println(v);
	  System.out.println(v.contains("May"));
	  System.out.println(v.size());
	  
	}
}