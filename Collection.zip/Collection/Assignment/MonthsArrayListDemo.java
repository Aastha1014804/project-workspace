import java.util.ArrayList;
import java.util.Iterator;
class MonthsArrayListDemo
{
    public static void main(String args[])
	{
	  ArrayList<String> a=new ArrayList<String>();
	  a.add("January");
	  a.add("February");
	  a.add("March");
	  a.add("April");
	  a.add("May");
	  a.add("June");
	  a.add("July");
	  a.add("August");
	  a.add("September");
	  a.add("October");
	  a.add("November");
	  a.add("December");
	  
	 System.out.println(a);
	
	for(String j:a)
	{
		System.out.println(j);
	}
	 
     System.out.println("Printing using iterator");
	 
	  Iterator i=a.iterator();
	  while(i.hasNext())
	  {
		  System.out.println(i.next());
	  }
	  
	}
}