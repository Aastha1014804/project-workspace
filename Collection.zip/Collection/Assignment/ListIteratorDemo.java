import java.util.ArrayList;
import java.util.ListIterator;
class ListIteratorDemo
{
    public static void main(String args[])
	{
	  ArrayList<String> a=new ArrayList<String>();
	  a.add("January");
	  a.add("February");
	  a.add("March");
	  a.add("April");
	  a.add("May");
	  a.add("June");
	  a.add("July");
	  a.add("August");
	  a.add("September");
	  a.add("October");
	  a.add("November");
	  a.add("December");
	  
	 System.out.println(a);
	
	
	 
	  ListIterator li=a.listIterator();
	  li.next(); //feb
	  li.next(); //march
	  while(li.hasPrevious())
	  {
		  System.out.println(li.previous()); //feb jan
	  }
	  //li.add("Yash");
	  //System.out.println(a);
	  li.set("Technologies"); //january is replaced by technologies
	  System.out.println(a);
	  
	}
}