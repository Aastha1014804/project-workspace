import java.util.HashSet;
import java.util.Iterator;
class HashSetDemo
{
    public static void main(String args[])
	{
	  HashSet<String> h=new HashSet<String>();
	  h.add("January");
	  h.add("February");
      h.add("March");
	  h.add("April");
	  h.add("May");
	  h.add("June");
	  h.add("July");
	  h.add("July");
	  h.add("August");
	  h.add("September");
	  h.add("October");
	  h.add("November");
	  h.add("December");
	  
	 System.out.println(h);
	
	 
	  Iterator i=h.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }
	  h.add("Yash");
	  System.out.println(h);
	  //h.set(2, "Summer");
	  //System.out.println(h);
	  
	}
}