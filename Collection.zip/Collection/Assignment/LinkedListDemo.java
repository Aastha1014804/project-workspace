import java.util.LinkedList;
import java.util.Iterator;
class LinkedListDemo
{
    public static void main(String args[])
	{
	  LinkedList<String> l=new LinkedList<String>();
	  l.add("January");
	  l.add("February");
      l.add("March");
	  l.add("April");
	  l.add("May");
	  l.add("June");
	  
	
	  Iterator i=l.iterator();
	  
	  while(i.hasNext())
	  {
		  System.out.println(i.next()); 
	  }
	  l.addLast(" Yash ");
	 
	  l.addLast(" Technologies ");
	  System.out.println(l);
	 
	}
}