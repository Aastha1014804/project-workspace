public class CheckingAccount extends Account{

    public CheckingAccount() {
        super();
    }
    CheckingAccount(int accountNumber)
    {
        super(accountNumber);
    }

    public void deposit(double amount)
    {
        if(amount>0)
        {
        balance += amount;
        System.out.println("Deposited amount is: " + amount);
        System.out.println("Current Balance is: " + balance);
        }
        else
        {
           System.out.println("Negative amount cannot be Deposited."); 
        }
    }

    public void withdrawn(double amount)
    {
        if(amount<=balance)
        {
        balance -= amount;
        System.out.println("Withdrawn amount is: " + amount);
        System.out.println("Current Balance is: " + balance);
        }
        else
        {
           System.out.println("Amount cannot be withdrawn."); 
        }
    }
}