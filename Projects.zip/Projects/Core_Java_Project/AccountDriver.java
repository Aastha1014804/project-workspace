
import java.util.Scanner;
public class AccountDriver
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Account accounts[]=new Account[10];
        int numAccount=0;
        int choice;

        do{
            choice = menu(sc);
            System.out.println();

            if(choice==1)
            {
                accounts[numAccount++]= createAccount(sc);
            }
            else if(choice==2)
            {
                doDeposit(accounts,numAccount,sc);
            }
            else if(choice==3)
            {
                doWithdrawn(accounts,numAccount,sc);
            }
            
            else {
                System.out.println("GoodBye ! ");
            }
            System.out.println("");
        } while(choice!=4);
    }

    public static int searchAccount(Account accounts[], int count, int accountNumber) {

        for(int i=0; i<count; i++) {
            if(accounts[i].getAccountNumber() == accountNumber) {
                return i;
            }
        }

        return -1; 
    }

public static void doDeposit(Account account[],int count,Scanner sc)
{
    System.out.println("Please enter account number : ");
    int accountNumber=sc.nextInt();
    int index= searchAccount(account, count,accountNumber);
    if(index>=0)
    {
        System.out.println("Please enter Deposit amount: ");
        double amount=sc.nextDouble();
        account[index].deposit(amount);
    }
    else{
        System.out.println("No exits account with this number: ");
    }

}

public static void doWithdrawn(Account accounts[],int count,Scanner sc)
{
    System.out.println("Enter the account number: ");
    int accountNumber=sc.nextInt();
    int index=searchAccount(accounts,count,accountNumber);
    if(index>=0)
    {
        System.out.println("Please enter the amount you want to withdraw");
        double amount=sc.nextDouble();
        accounts[index].withdrawn(amount);
    }
    else{
        System.out.println("No account exits with this number: ");
    }
}



public static int accountMenu(Scanner sc)
{
    System.out.println("Select Account Type");
    System.out.println("1. Checking Account");
    System.out.println("2. Savings Account");

    int choice;
    do{
        System.out.print("Enter choice: ");
        choice=sc.nextInt();
    }while(choice<1 || choice>2);
    return choice;

}



public static Account createAccount(Scanner sc)
{
    Account account=null;
    int choice=accountMenu(sc);
    
    int accountNumber;
    System.out.print("Enter Account Number: ");
    accountNumber = sc.nextInt();
    if(choice==1)
    {
       account = new CheckingAccount(accountNumber);
    }
    else{
       
        account = new SavingsAccount(accountNumber);
    }
    return account;

}

 public static int menu(Scanner sc)
 {
    System.out.println("Bank Account Menu");
    System.out.println("1. Create New Account");
    System.out.println("2. Deposit Funds");
    System.out.println("3. Withdraw Funds");
    System.out.println("4. Quit");

    int choice;
    do{
        System.out.println("Enter choice");
        choice=sc.nextInt();

    }while(choice<1 || choice>4);
    return choice;
 }

}