public abstract class Account
{
   private int accountNumber;
   protected double balance;
   public Account()
   {
      
   }


   public Account(int accountNumber)
   {
       this.accountNumber=accountNumber;
   }
   public int getAccountNumber()
   {
       return accountNumber;
   }
   public double getBalance()
   {
       return balance;
   }

   public abstract void deposit(double amount);
   public abstract void withdrawn(double amount);

}