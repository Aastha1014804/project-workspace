package com.yash.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.bean.Login;

public class LoginDao {
	JdbcTemplate temp;

	public JdbcTemplate getTemp() {
		return temp;
	}

	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}

	public int save(Login l) {
		String sql = "Insert into login(username,email,gender,dept) values ('" + l.getUsername() + "','" + l.getEmail()
				+ "','" + l.getGender() + "','" + l.getDept() + "')";
		return temp.update(sql);
	}

	public int delete(String username) {
		String sql = "delete from login where username='"+ username +"'";
		return temp.update(sql);
	}

	public int update(Login l) {
		String sql = "update login set email='" + l.getEmail() + "',gender='" + l.getGender() + "',dept='" + l.getDept()+ "'where username='"+l.getUsername()+"'";
		return temp.update(sql);
	}

	public Login getLoginById(String username) {
		String sql = "select * from login where username=?";
		return temp.queryForObject(sql, new Object[] { username }, new BeanPropertyRowMapper<Login> (Login.class));
	}

	public List<Login> getLoginDetails(){    
	    return temp.query("select * from login",new RowMapper<Login>(){    
	        public Login mapRow(ResultSet rs, int row) throws SQLException {    
	            Login e=new Login();    
	            e.setUsername(rs.getString(1));    
	            e.setEmail(rs.getString(2));    
	            e.setGender(rs.getString(3));    
	            e.setDept(rs.getString(4));    
	            return e;    
	        }    
		});
	}
}
