package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model) 
	{
		model.addAttribute("name", "Aastha");

		ArrayList<String> list = new ArrayList<String>();
		list.add("Aastha");
		list.add("Manesha");
		list.add("Sanjay");
		list.add("Harshit");
		list.add("Stuti");
		
		model.addAttribute("list", list);
		return "index";

	}
	
	@RequestMapping(path="/request",method=RequestMethod.POST)
	public String handlerequest(@RequestParam("email") String emailid, Model model)
	{
	System.out.println(emailid);
	model.addAttribute("email", emailid);
	return "test";
	}
}
